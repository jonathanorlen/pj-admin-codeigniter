
 <a style="padding:13px; margin-bottom:10px" class="btn btn-app green" href="<?php echo base_url().'pembelian/po/tambah'; ?>">
              <i class="fa fa-plus"></i> Tambah PO
            </a>
            
            <a style="padding:13px; margin-bottom:10px" class="btn btn-app blue" href="<?php echo base_url().'pembelian/po/daftar_po'; ?>">
              <i class="fa fa-list"></i> Daftar PO
            </a>