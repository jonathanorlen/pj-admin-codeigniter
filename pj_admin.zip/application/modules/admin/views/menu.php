<div class="">
  <div class="page-content">

    <div class="box-footer clearfix">
     
    
    </div>


<div id="box_load">
 <?php echo @$konten; ?>
 </div>
</div>
</div>
