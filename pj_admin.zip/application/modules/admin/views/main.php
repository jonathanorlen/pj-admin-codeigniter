
<!-- jQuery 2.1.4 -->
<script src="<?php echo base_url() . 'component/admin/assets/global/plugins/jQuery-2.1.4.min.js '?>" type="text/javascript"></script>

<?php echo $this->load->view('general/top_scr'); ?>
<?php echo $this->load->view('general/sidebar'); ?>
<?php echo $konten; ?>
<?php echo $this->load->view('general/footer'); ?>

