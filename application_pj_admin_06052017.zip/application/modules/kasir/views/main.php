
<!-- jQuery 2.1.4 -->
<script src="<?php echo base_url() . 'component/admin/plugins/jQuery/jQuery-2.1.4.min.js '?>" type="text/javascript"></script>

<?php echo $this->load->view('admin/general/top_scr'); ?>
<?php echo $this->load->view('admin/general/sidebar'); ?>
<?php echo $konten; ?>
<?php echo $this->load->view('admin/general/footer'); ?>

