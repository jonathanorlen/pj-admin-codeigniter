<div class="page-container">
  <!-- BEGIN SIDEBAR -->
 <!--  <div class="page-sidebar-wrapper">
    <div class="page-sidebar navbar-collapse collapse">
      <ul class="page-sidebar-menu page-sidebar-menu-hover-submenu " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200">
        <li class="start active ">
          <a href="<?php echo base_url() . 'admin/' ?>">
            <i class="icon-home"></i>
            <span class="title">Dashboard</span>
            <span class="selected"></span>
          </a>
        </li>
         <li class="tooltips" data-container="body" data-placement="right" data-html="true">
          <a href="<?php echo base_url() . 'pembelian' ?>">
            <i class="fa fa-money" style="color: #fff"></i>
            <span class="title">Pembelian</span>
          </a>
        </li>

        <li class="tooltips" data-container="body" data-placement="right" data-html="true">
          <a href="<?php echo base_url() . 'stok' ?>">
            <i class="fa fa-cubes" style="color: #fff"></i>
            <span class="title">Stok</span>
          </a>
        </li>

        <li class="tooltips" data-container="body" data-placement="right" data-html="true">
          <a href="<?php echo base_url() . 'transaksional' ?>">
            <i class="fa fa-exchange" style="color: #fff"></i>
            <span class="title">Transaksional</span>
          </a>
        </li>
        <li class="tooltips" data-container="body" data-placement="right" data-html="true">
          <a href="<?php echo base_url() . 'keuangan' ?>">
            <i class="fa fa-dollar" style="color: #fff"></i>
            <span class="title">Keuangan</span>
          </a>
        </li>
        <li class="tooltips" data-container="body" data-placement="right" data-html="true">
          <a href="<?php echo base_url() . 'analisa' ?>">
            <i class="fa fa-gears" style="color: #fff"></i>
            <span class="title">Analiasa</span>
          </a>
        </li>
          

      </ul>

    </div>
  </div> -->