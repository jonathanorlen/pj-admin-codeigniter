<?php echo $this->load->view('admin/general/top_scr'); ?>
<?php echo $this->load->view('admin/general/sidebar'); ?>
<?php echo $konten; ?>
<?php echo $this->load->view('admin/general/footer'); ?>

