<?php
$class_dir = '../class';
?>