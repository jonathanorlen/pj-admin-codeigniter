
<div class="">
	<div class="page-content">
		
		<div id="box_load">
			<?php echo @$konten; ?>
		</div>
	</div>
</div>

